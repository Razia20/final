#include <iostream>
#include <conio.h>
#include <string.h>
#include "ThreeD.h"

using namespace std;
#define PI 3.1416

void Choose(){
    //Making the UI for choose option
    cout << "\n\n**************************************" << endl;

    cout << "Please enter a choice from below:" <<endl;
    cout << "What Are The Dimensions Of Your Shape?" <<endl;
    cout << "1) 2-D \n2) 3-D \n3) Exit \n" <<endl;
    cout << "Please enter choice:";
}

ThreeD :: ThreeD(){} //constructor of 3D class

ThreeD :: ~ThreeD(){} ////Destractor of 3D class

    void ThreeD :: Sphere (){
        cout << "Please enter the radius of your Sphere:";
        float radious;//variable for get radious of Sphere
        cin >> radious;
        float volume;//variable for calculating volume
        volume = (4* PI *radious*radious*radious)/3;
        cout << "Volume = 4/3 * PI * " << radious << "^3" << " = " << volume << " m^3"<<endl;

        Choose(); //calling Choose function for choose option
    }
    void ThreeD :: Cube (){
        cout << "Please enter the edge of your Cube:";
        float edge;//variable for get edge of Cube
        cin >> edge;
        float volume;//variable for calculating volume
        volume = edge*edge*edge;
        cout << "Volume = " << edge << "^3" << " = " << volume << " m^3"<<endl;

        Choose(); //calling Choose function for choose option
    }
    void ThreeD ::Cuboid (){
        cout << "Please enter the length of your Cuboid:";
        float length;//variable for get length of Cuboid
        cin >> length;
        cout << "Please enter the breadth of your Cuboid:";
        float breadth;//variable for get breadth of Cuboid
        cin >> breadth;
        cout << "Please enter the Height(Thickness) of your Cuboid:";
        float height;//variable for get height of Cuboid
        cin >> height;

        float volume;//variable for calculating volume
        volume = length*breadth*height;
        cout << "Volume = " << length <<"*"<< breadth<<"*" << height << " = " << volume << " m^3"<<endl;

        Choose(); //calling Choose function for choose option
    }
    void ThreeD :: Cylinder(){
        cout << "Please enter the radius of your Cylinder:";
        float radius;//variable for get radius of Cylinder
        cin >> radius;
        cout << "Please enter the Height of your Cylinder:";
        float height;//variable for get height of Cylinder
        cin >> height;

        float volume;//variable for calculating volume
        volume = PI*radius*radius*height;
        cout << "Volume = PI*" << radius <<"^2"<< "*" << height << " = " << volume << " m^3"<<endl;

        Choose(); //calling Choose function for choose option
    }
    void ThreeD :: Pyramid(){
        cout << "Please enter the length of your Pyramid:";
        float length;//variable for get length of Pyramid
        cin >> length;
        cout << "Please enter the width of your Pyramid:";
        float width;//variable for get width of Pyramid
        cin >> width;
        cout << "Please enter the Height of your Pyramid:";
        float height;//variable for get height of Pyramid
        cin >> height;

        float volume;//variable for calculating volume
        volume = (length*width*height)/3;
        cout << "Volume = " << length <<"*"<< width<<"*" << height <<"/3"<< " = " << volume << " m^3"<<endl;

        Choose(); //calling Choose function for choose option
    }
