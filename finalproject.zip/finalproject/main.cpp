#include <iostream>
#include <conio.h>
#include <stdlib.h>
#include <string.h>
#include <ThreeD.h>

using namespace std;
#define PI  3.1416

void UI(){
    //Making the UI for choose option
    cout << "\n\n**************************************" << endl;

    cout << "Please enter a choice from below:" <<endl;
    cout << "What Are The Dimensions Of Your Shape?" <<endl;
    cout << "1) 2-D \n2) 3-D \n3) Exit \n" <<endl;
    cout << "Please enter choice:";
}


//class for 2-D shapes
class TwoD {
public:
    TwoD(); //constractor
    ~TwoD();//destractor
    void Circle (); //function of 2d class
    void Square (); //function of 2d class
    void Rectangle (); //function of 2d class
    void Trapezium();//function of 2d class
    void Parallelogram();//function of 2d class
    void Rhombus();//function of 2d class
    void Triangle();//function of 2d class
};


TwoD :: TwoD() {} //constractor

TwoD :: ~TwoD() {} //destractor

    void TwoD :: Circle (){
        cout << "Please enter the radius of your circle:";
        float radious;//variable for get radious of circle
        cin >> radious;
        float perimeter;
        perimeter = (2* PI *radious);//variable for calculating perimeter
        cout << "Perimeter = 2 * PI * " << radious  << " = " << perimeter << " m"<<endl;
        float area;//variable for calculating area
        area = ((4*PI*radious*radious*radious)/3);
        cout << "Area = (4/3) * PI * ("<< radious << ")^2 = " <<area << " m^2" <<endl;
        UI(); //calling UI function for choose option
    }
    void TwoD ::Square (){
        cout << "Please enter the side of your square:";
        float side;//variable for one side of square
        cin >> side;
        float perimeter; //variable for calculating perimeter
        perimeter = (4*side);
        cout << "Perimeter = 4*" << side  << " = " << perimeter << " m"<<endl;
        float area; //variable for calculating area
        area = (side *side);
        cout << "Area = "<< side <<"*" <<side << " = " <<area << " m^2" <<endl;
        UI(); //calling UI function for choose option
    }
    void TwoD :: Rectangle (){
        float length;//variable for length
        float breadth; ////variable for breadth
        cout << "Please enter the length of your Rectangle:";
        cin >> length;
        cout << "Please enter the breadth of your Rectangle:";
        cin >>breadth;

        float perimeter; //variable for calculating perimeter
        perimeter = 2*(length + breadth);//2(l+b)
        cout << "Perimeter = 2*(" << length << "+" <<breadth << ") "  << " = " << perimeter  << " m"<<endl;
        float area; //variable for calculating area
        area = (length * breadth);
        cout << "Area = "<< length <<"*" <<breadth << " = " <<area << " m^2" <<endl;
        UI();
    }
    void TwoD :: Trapezium(){
        float aBase;//variable for upper base
        float bBase; //variable for lower base
        float cSide;//variable for left side
        float dSide; //variable for right side
        float height; //variable for height of the Trapezium
        cout << "Please enter the Upper base of your Trapezium:";
        cin >> aBase;
        cout << "Please enter the Lower base of your Trapezium:";
        cin >>bBase;
        cout << "Please enter the Left Side of your Trapezium:";
        cin >> cSide;
        cout << "Please enter the Right Side of your Trapezium:";
        cin >>dSide;

        cout << "Please enter the Height of your Trapezium:";
        cin >> height;

        float perimeter; //variable for calculating perimeter
        perimeter = (aBase + bBase + cSide + dSide);
        cout << "Perimeter = " << aBase << "+" << bBase <<"+"<< cSide << "+" << dSide<< " = " << perimeter  << " m"<<endl;
        float area; //variable for calculating area
        area = (height * (aBase + bBase))/2 ;
        cout << "Area = "<< height <<"*" << "("<< aBase << "+" << bBase << ")" << "/2" << " = " <<area << " m^2" <<endl;

        UI(); //calling UI function for choose option

    }
    void TwoD :: Parallelogram(){
        float base;//variable for base
        float side; ////variable for side
        float height; ////variable for height
        cout << "Please enter the base of your Parallelogram:";
        cin >> base;
        cout << "Please enter the side of your Parallelogram:";
        cin >>side;
        cout << "Please enter the Height of your Parallelogram:";
        cin >>height;

        float perimeter; //variable for calculating perimeter
        perimeter = 2*(base + side);//2(l+b)
        cout << "Perimeter = 2*(" << base << "+" <<side << ") "  << " = " << perimeter  << " m"<<endl;
        float area; //variable for calculating area
        area = (base * height);
        cout << "Area = "<< base <<"*" << height << " = " <<area << " m^2" <<endl;

        UI(); //calling UI function for choose option

    }
    void TwoD :: Rhombus(){
        cout << "Please enter the side of your Rhombus:";
        float side;//variable for side of Rhombus
        cin >> side;
        float P,Q; //variable for one P diagonal and Q diagonal of Rhombus
        cout << "Please enter the P Diagonal of your Rhombus:";
        cin >> P;
        cout << "Please enter the Q Diagonal of your Rhombus:";
        cin >> Q;

        float perimeter; //variable for calculating perimeter
        perimeter = (4*side);
        cout << "Perimeter = 4*" << side  << " = " << perimeter << " m"<<endl;
        float area; //variable for calculating area
        area = (P *Q)/2;
        cout << "Area = "<< P <<"*" <<Q << "/2"<< " = " <<area << " m^2" <<endl;

        UI(); //calling UI function for choose option

    }
    void TwoD :: Triangle(){
        float base;//variable for base
        float left; ////variable for left side
        float right; ////variable for right side
        float height; ////variable for height
        cout << "Please enter the base of your Triangle:";
        cin >> base;
        cout << "Please enter the left side hand of your Triangle:";
        cin >>left;
        cout << "Please enter the right side hand of your Triangle:";
        cin >>right;

        cout << "Please enter the Height of your Triangle:";
        cin >>height;

        float perimeter; //variable for calculating perimeter
        perimeter = (base + left + right);
        cout << "Perimeter = " << base << "+" <<left << "+"  << right << " = " << perimeter  << " m"<<endl;
        float area; //variable for calculating area
        area = (base * height)/2;
        cout << "Area = "<< base <<"*" << height << "/2" <<" = " <<area << " m^2" <<endl;

        UI(); //calling UI function for choose option

    }



int main()
{
    TwoD my2D; //creating object of TwoD class
    ThreeD my3D;//creating object of ThreeD class

    //making initial UI for Geometry App
    cout <<"Geometry App" <<endl;
    cout << "#########################################" <<endl;
    cout << "Welcome to the Geometry App!\t\t#" <<endl;
    cout << "#########################################"<<endl <<endl;
    cout << "I will let you calculate the area and perimeter of 2-D shapes, and volume of 3-D shapes." <<endl;

    char shape ; //Variable for taking input of the shape

    UI(); //calling the UI function
    int choice; //variable for choose option
    while (choice != 3){
        cin >> choice;//Variable for taking input of the Choice
        if(choice == 1){
            cout << "*************************************" <<endl;
            cout << "You picked 1.\n" <<endl;

            cout << "1)2-D Shapes" <<endl;
            cout << "What shape would you pick?" <<endl;
            cout << "a) Circle \nb) Square \nc) Rectangle \nd) Trapezium \ne) Parallelogram \nf) Rhombus \ng) Triangle\n" <<endl;

            cout << "Please pick a shape:";

            cin >> shape;
                switch(shape){
                //for lowercase letter
                case 'a' :
                    my2D.Circle(); //calling method of class TwoD
                    break;
                case 'b' :
                    my2D.Square(); //calling method of class TwoD
                    break;
                case 'c' :
                    my2D.Rectangle();//calling method of class TwoD
                    break;
                case 'd' :
                    my2D.Trapezium();//calling method of class TwoD
                    break;
                case 'e' :
                    my2D.Parallelogram();//calling method of class TwoD
                    break;
                case 'f' :
                    my2D.Rhombus();//calling method of class TwoD
                    break;
                case 'g' :
                    my2D.Triangle();//calling method of class TwoD
                    break;

                //for uppercase letter
                case 'A' :
                    my2D.Circle(); //calling method of class TwoD
                    break;
                case 'B' :
                    my2D.Square(); //calling method of class TwoD
                    break;
                case 'C' :
                    my2D.Rectangle();//calling method of class TwoD
                    break;
                case 'D' :
                    my2D.Trapezium();//calling method of class TwoD
                    break;
                case 'E' :
                    my2D.Parallelogram();//calling method of class TwoD
                    break;
                case 'F' :
                    my2D.Rhombus();//calling method of class TwoD
                    break;
                case 'G' :
                    my2D.Triangle();//calling method of class TwoD
                    break;


                default :
                    cout << "Enter a valid Shape request" <<endl;

                }

        }
        else if(choice == 2){
        cout << "*************************************" <<endl;
            cout << "You picked 2.\n" <<endl;

            cout << "1)3-D Shapes" <<endl;
            cout << "What shape would you pick?" <<endl;
            cout << "a) Sphere \nb) Cube \nc) Cuboid \nd) Cylinder \ne) Pyramid \n" <<endl;

            cout << "Please pick a shape:";

            cin >> shape;
                switch(shape){
                //for lower case letters
                case 'a' :
                    my3D.Sphere();//calling method of class ThreeD
                    break;
                case 'b' :
                    my3D.Cube();//calling method of class ThreeD
                    break;
                case 'c' :
                    my3D.Cuboid();//calling method of class ThreeD
                    break;
                case 'd' :
                    my3D.Cylinder();//calling method of class ThreeD
                    break;
                case 'e' :
                    my3D.Pyramid();//calling method of class ThreeD
                    break;


                //for uppercase letters
                case 'A' :
                    my3D.Sphere();//calling method of class ThreeD
                    break;
                case 'B' :
                    my3D.Cube();//calling method of class ThreeD
                    break;
                case 'C' :
                    my3D.Cuboid();//calling method of class ThreeD
                    break;
                case 'D' :
                    my3D.Cylinder();//calling method of class ThreeD
                    break;
                case 'E' :
                    my3D.Pyramid();//calling method of class ThreeD
                    break;

                default :
                    cout << "Enter a valid Shape request" <<endl;
                }
        }
        else if(choice == 3){
            cout << "\nYou picked 3) Exit.\n" <<endl;

            cout << "#####################################" <<endl;
            cout << "#				    #					#				    #" <<endl;
            cout << "#	   See you again! 	    # " <<endl;
            cout << "#	      Goodbye! 		    # " <<endl;
            cout << "#				    #					#				    #" <<endl;
            cout << "#####################################" <<endl;

            exit(0);
        }
        else{
            cout << "Enter a valid Choice!!!" <<endl;

            UI();
        }

    }

    return 0;
}
