#ifndef THREED_H
#define THREED_H


class ThreeD{
    public:
    ThreeD(); //constractor
    ~ThreeD(); //destractor
    void Sphere ();//function of 3d class
    void Cube ();//function of 3d class
    void Cuboid ();//function of 3d class
    void Cylinder();//function of 3d class
    void Pyramid();//function of 3d class
};

#endif // THREED_H
